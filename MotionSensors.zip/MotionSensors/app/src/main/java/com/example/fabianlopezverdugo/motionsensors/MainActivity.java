package com.example.fabianlopezverdugo.motionsensors;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private SensorManager mSensorManager;
    private SensorManager mGyroSensorManager;
    private Sensor mSensor;
    private Sensor mGyroSensor;
    private float x;
    private float y;
    private DrawView drawView; /* This class is implemented at the bottom of the activity */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        drawView = new DrawView(this);
        setContentView(drawView); /* Here, instead of using the main activity as the content view, we will be using a class that extends the view class to draw from that class to the main activity */
        checkForSensors();
    }

    /* Function checkForSensors: */
    /* It checks if the device currently has the two devices that will be used */
    /* Even though this is checked in the Android Manifest, this is a way to check in code if it has the necessary hardware */
    private void checkForSensors(){
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE); /* The Sensor Manager for the Accelerometer */
        mGyroSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE); /* The Sensor Manager for the Gyroscope */
        if (mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null){ /* Check if it's available */
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER); /* Obtain the Sensor from the manager and keep it in the mSensor Variable */
            System.out.println("There is an accelerometer");
        }
        else {
            // In this part we could exit the application because we don't have an accelerometer
            System.out.println("No Accelerometer Detected");
        }

        if (mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null){ /* Check if it's available */
            mGyroSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE); /* Obtain the Sensor from the manager and keep it in the mGyroSensor Variable */
            System.out.println("There is a Gyroscope");
        }
        else {
            // In this part we could exit the application because we don't have a gyroscope
            System.out.println("No Gyroscope Detected");
        }
    }

    /* This part of the code will be implemented each time the sensor changes */
    @Override
    public void onSensorChanged(SensorEvent event) {
        SensorEvent sensorEvent = event;
        if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){ /* used to identify if the event was triggered by the accelerometer or the gyroscope */
            this.drawView.addX(event.values[0]); /* To add the value given by the accelerometer to X in DrawView class */
            this.drawView.addY(event.values[1]); /* To add the value given by the accelerometer to Y in DrawView class */
            this.drawView.invalidate(); /* To refresh the onDraw in DrawView class*/
            //System.out.println("x="+event.values[0]+"|y="+event.values[1]+"|z="+event.values[2]);
        }
        if(sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE){
            this.drawView.setGyroX(String.valueOf(event.values[0])); /* Set x text of the gyroscope */
            this.drawView.setGyroY(String.valueOf(event.values[1])); /* Set y text of the gyroscope */
            this.drawView.setGyroZ(String.valueOf(event.values[2])); /* Set z text of the gyroscope */
            this.drawView.invalidate(); /* To refresh the onDraw in DrawView class*/
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    /* The next to function will be crucial to not drain the battery of the device */
    @Override
    protected void onResume() {
        super.onResume();
        /* when the application resumes then the sensor can start listening again */
        mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        mGyroSensorManager.registerListener(this, mGyroSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        /* when the application pauses, then the sensor should stop listening to avoid wasting the battery of the device */
        mSensorManager.unregisterListener(this);
        mGyroSensorManager.unregisterListener(this);
    }

    /* DrawView classt to draw in the main activity */
    public class DrawView extends View {

        private float xCenter = 100.0f;
        private float yCenter = 100.0f;

        private String xGyro = "";
        private String yGyro = "";
        private String zGyro = "";

        public DrawView(Context context) {
            super(context);
        }

        /* This function is for drawing in the view, it will be called each time the method invalidate is called, and when the class is created */
        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            //int x = getWidth();
            //int y = getHeight();
            int radius;
            radius = 100;
            Paint paint = new Paint();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            canvas.drawPaint(paint);
            // Until this point, the only thing drawn is a white rectangle, as the background
            paint.setColor(getResources().getColor(android.R.color.holo_red_dark)); //Set red color for the circle
            //System.out.println("x="+xCenter+"|y="+yCenter);
            canvas.drawCircle(xCenter, yCenter, radius, paint); //Draw the circle in (xCenter,yCenter), with 100 of radius and the paint attributes given before
            paint.setTextSize(70); //Here you can change the size of the text to adjust to your device
            canvas.drawText("Red Ball is for Accelerometer",100,200,paint); //Text is drawn in (100,200) with paint attributes
            paint.setTextSize(80); //Here you can change the size of the text to adjust to your device
            paint.setColor(getResources().getColor(android.R.color.black));
            canvas.drawText("Gyroscope Values",100,400,paint); //Text is drawn in (100,400) with paint attributes
            canvas.drawText("x:"+xGyro+"m/s",100,500,paint); //Text is drawn in (100,500) with paint attributes
            canvas.drawText("y:"+yGyro+"m/s",100,600,paint); //Text is drawn in (100,600) with paint attributes
            canvas.drawText("z:"+zGyro+"m/s",100,700,paint); //Text is drawn in (100,700) with paint attributes
        }

        /* Functions addX and addY */
        /* This functions check for the boundaries of the device */
        /* Otherwise, the ball would move and move and eventually will be lost in the space */
        /* Also changes the xCenter and yCenter value to draw each time the onDraw function is called */
        public void addX(float add){
            DisplayMetrics displaymetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
            int width = displaymetrics.widthPixels;
            if (xCenter >= width-100){
                xCenter -= 3;
            } else if(xCenter <= 100) {
                xCenter += 3;
            } else {
                xCenter += add*-1;
            }
        }

        public void addY(float add){
            DisplayMetrics displaymetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
            int height = displaymetrics.heightPixels;
            if (yCenter >= height-350){
                yCenter -= 3;
            } else if(yCenter <= 100) {
                yCenter += 3;
            } else {
                yCenter += add;
            }
        }

        /* Functions setGyroX, setGyroY and setGyroZ */
        /* The only action of these functions is to change their respective text */
        /* x, y or z to change it at the onDraw function when called*/
        public void setGyroX(String setText){
            this.xGyro = setText;
        }

        public void setGyroY(String setText){
            this.yGyro = setText;
        }

        public void setGyroZ(String setText){
            this.zGyro = setText;
        }

    }

}
